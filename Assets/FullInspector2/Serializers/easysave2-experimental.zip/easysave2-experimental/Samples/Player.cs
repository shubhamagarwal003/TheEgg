using System.Collections.Generic;

namespace FullInspector.Samples.EasySave2 {
    public class Player : BaseBehavior<EasySave2Serializer> {
        [Name("PlayerName")]
        public string playerName;

        [Name("HitPoints")]
        public int hitpoints;

        // name is set to [Name("FullInspector.Samples.EasySave2.Player.inventory")]
        public List<int> inventory;
    }
}