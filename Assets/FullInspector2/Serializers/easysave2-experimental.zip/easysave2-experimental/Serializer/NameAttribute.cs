﻿using System;

namespace FullInspector {
    /// <summary>
    /// Gives a field or property a specific name for EasySave2 to use when serializing.
    /// </summary>
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public class NameAttribute : Attribute {
        /// <summary>
        /// The name of the field/property.
        /// </summary>
        public string Name;

        /// <summary>
        /// Set the name of the field/property.
        /// </summary>
        /// <param name="name">The name.</param>
        public NameAttribute(string name) {
            Name = name;
        }
    }
}