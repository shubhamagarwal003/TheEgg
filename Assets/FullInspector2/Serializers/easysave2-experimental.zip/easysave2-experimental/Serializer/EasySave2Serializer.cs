using FullInspector.Internal;
using System;
using System.Reflection;
using UnityEngine;
using UnityObject = UnityEngine.Object;

// WARNING: The EasySave2Serializer is **experimental**. Support will be limited. If you seek ease
//          of use, the Json.NET serializer is recommended. If you seek performance, the
//          protobuf-net serializer is recommended.

namespace FullInspector {
    public class EasySave2Serializer : BaseSerializer {
        private const BindingFlags MethodSearchFlags =
            BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

        private static string GetName(MemberInfo member) {
            // custom name?
            var name = member.GetAttribute<NameAttribute>();
            if (name != null) {
                return name.Name;
            }

            // class name + name
            return member.DeclaringType.FullName + "." + member.Name;
        }

        internal override string Serialize(MemberInfo storageType, object value, ISerializationOperator serializationOperator) {
            string name = GetName(storageType);
            ES2.Save(name, value);
            return "";
        }

        internal Type GetMemberType(MemberInfo member) {
            var field = member as FieldInfo;
            if (field != null) return field.FieldType;

            var property = member as PropertyInfo;
            return property.PropertyType;
        }

        internal override object Deserialize(MemberInfo storageType, string serializedState, ISerializationOperator serializationOperator) {
            string name = GetName(storageType);

            Type type = GetMemberType(storageType);

            if (type == typeof(string)) {
                return ES2.Load<string>(name);
            }
            if (type == typeof(byte)) {
                return ES2.Load<byte>(name);
            }
            if (type == typeof(bool)) {
                return ES2.Load<bool>(name);
            }
            if (type == typeof(char)) {
                return ES2.Load<char>(name);
            }
            if (type == typeof(int)) {
                return ES2.Load<int>(name);
            }
            if (type == typeof(long)) {
                return ES2.Load<long>(name);
            }
            if (type == typeof(short)) {
                return ES2.Load<short>(name);
            }
            if (type == typeof(uint)) {
                return ES2.Load<uint>(name);
            }
            if (type == typeof(ulong)) {
                return ES2.Load<ulong>(name);
            }
            if (type == typeof(ushort)) {
                return ES2.Load<ushort>(name);
            }

            if (type == typeof(Vector2)) {
                return ES2.Load<Vector2>(name);
            }
            if (type == typeof(Vector3)) {
                return ES2.Load<Vector3>(name);
            }
            if (type == typeof(Vector4)) {
                return ES2.Load<Vector4>(name);
            }
            if (type == typeof(Quaternion)) {
                return ES2.Load<Quaternion>(name);
            }
            if (type == typeof(Color)) {
                return ES2.Load<Color>(name);
            }
            if (type == typeof(Color)) {
                return ES2.Load<Color>(name);
            }
            if (type == typeof(Texture2D)) {
                return ES2.Load<Texture2D>(name);
            }
            if (type == typeof(Material)) {
                return ES2.Load<Material>(name);
            }
            if (type == typeof(Mesh)) {
                return ES2.Load<Mesh>(name);
            }
            if (type == typeof(AudioClip)) {
                return ES2.Load<AudioClip>(name);
            }
            if (type == typeof(Rect)) {
                return ES2.Load<Rect>(name);
            }
            if (type == typeof(Bounds)) {
                return ES2.Load<Bounds>(name);
            }

            // TODO: collections
            //if (type == typeof(Array)) {
            //    return ES2.Load<Array>(name);
            //}
            //if (type == typeof(Array)) {
            //    return ES2.Load<>(name);
            //}
            //if (type == typeof(Dictionary)) {
            //    return ES2.Load<Dictionary>(name);
            //}
            //if (type == typeof(List)) {
            //    return ES2.Load<>(name);
            //}<T>
            //if (type == typeof(Queue)) {
            //    return ES2.Load<>(name);
            //}<T>
            //if (type == typeof(HashSet)) {
            //    return ES2.Load<>(name);
            //}<T>
            //if (type == typeof(Stack)) {
            //    return ES2.Load<>(name);
            //}<T>

            if (type == typeof(Transform)) {
                return ES2.Load<Transform>(name);
            }
            if (type == typeof(SphereCollider)) {
                return ES2.Load<SphereCollider>(name);
            }
            if (type == typeof(BoxCollider)) {
                return ES2.Load<BoxCollider>(name);
            }
            if (type == typeof(CapsuleCollider)) {
                return ES2.Load<CapsuleCollider>(name);
            }
            if (type == typeof(MeshCollider)) {
                return ES2.Load<MeshCollider>(name);
            }
        }
    }
}