var class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_sample_platformer_move_behavior =
[
    [ "FixedUpdate", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_sample_platformer_move_behavior.html#acc195959c1368d69b795be6403e9e942", null ],
    [ "OnCollisionEnter2D", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_sample_platformer_move_behavior.html#a1c930e9e0d2c486dbcc6ae23beee5774", null ],
    [ "BaseHorizontalSpeed", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_sample_platformer_move_behavior.html#aba42abbc8c9ca00cbe395b287678827b", null ],
    [ "BaseJumpBurst", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_sample_platformer_move_behavior.html#a2497aa8c89a0f428bcca9afbc6308d24", null ],
    [ "HorizontalSpeed", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_sample_platformer_move_behavior.html#a0180a61b3083ee51bd0f3f80ebc583a3", null ],
    [ "JumpBurst", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_sample_platformer_move_behavior.html#a5016b1a66ce6883ec6f81d2c8dbe9093", null ]
];