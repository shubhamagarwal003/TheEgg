var class_full_inspector_1_1_inspector_order_attribute =
[
    [ "InspectorOrderAttribute", "class_full_inspector_1_1_inspector_order_attribute.html#ae0eed2808e85f98ac508a699e4539a0e", null ],
    [ "Order", "class_full_inspector_1_1_inspector_order_attribute.html#aab124362dd1d1aa9801859c26b0b6718", null ]
];