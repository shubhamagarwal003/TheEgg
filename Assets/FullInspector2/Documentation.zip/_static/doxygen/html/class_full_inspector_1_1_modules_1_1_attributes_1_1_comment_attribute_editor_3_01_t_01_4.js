var class_full_inspector_1_1_modules_1_1_attributes_1_1_comment_attribute_editor_3_01_t_01_4 =
[
    [ "Edit", "class_full_inspector_1_1_modules_1_1_attributes_1_1_comment_attribute_editor_3_01_t_01_4.html#ac34aaabbc61f5f4d0e4c0f41b28dcdfc", null ],
    [ "GetElementHeight", "class_full_inspector_1_1_modules_1_1_attributes_1_1_comment_attribute_editor_3_01_t_01_4.html#a89770b5139989d27cea218b2216dd1fd", null ]
];