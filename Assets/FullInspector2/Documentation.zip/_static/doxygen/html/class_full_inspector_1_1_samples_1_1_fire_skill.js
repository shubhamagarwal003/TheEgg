var class_full_inspector_1_1_samples_1_1_fire_skill =
[
    [ "Strength", "class_full_inspector_1_1_samples_1_1_fire_skill.html#a1c61317e1ebb2c6e84f72dd339a8fc79", null ]
];