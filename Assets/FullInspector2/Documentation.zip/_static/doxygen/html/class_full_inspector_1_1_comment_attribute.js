var class_full_inspector_1_1_comment_attribute =
[
    [ "CommentAttribute", "class_full_inspector_1_1_comment_attribute.html#ad7b29168d43f8f58e49991a654aadb0d", null ],
    [ "CommentAttribute", "class_full_inspector_1_1_comment_attribute.html#a0cf09794598a3fcc1bb605d649c1c6f3", null ],
    [ "Comment", "class_full_inspector_1_1_comment_attribute.html#a0fd9d6bc7d6f64f9325833c6f84ac016", null ],
    [ "Order", "class_full_inspector_1_1_comment_attribute.html#aa5de42903e91ab8e3e9ad779c12fae79", null ],
    [ "Type", "class_full_inspector_1_1_comment_attribute.html#ac55f028a5c6137fdd151147b54ea5cce", null ],
    [ "Order", "class_full_inspector_1_1_comment_attribute.html#a16765b76e72a15a75090d0ceaeae03bd", null ]
];