var class_full_inspector_1_1_samples_1_1_binary_formatter_sample_1_1_sample_binary_formatter_dictionaries =
[
    [ "Container", "struct_full_inspector_1_1_samples_1_1_binary_formatter_sample_1_1_sample_binary_formatter_dictionaries_1_1_container.html", "struct_full_inspector_1_1_samples_1_1_binary_formatter_sample_1_1_sample_binary_formatter_dictionaries_1_1_container" ],
    [ "Enum", "class_full_inspector_1_1_samples_1_1_binary_formatter_sample_1_1_sample_binary_formatter_dictionaries.html#a184ff365a09b7ad654df79a09d0053c5", [
      [ "ValueA", "class_full_inspector_1_1_samples_1_1_binary_formatter_sample_1_1_sample_binary_formatter_dictionaries.html#a184ff365a09b7ad654df79a09d0053c5a199bcd6a3343ed48683eb4b63cc42ded", null ],
      [ "ValueB", "class_full_inspector_1_1_samples_1_1_binary_formatter_sample_1_1_sample_binary_formatter_dictionaries.html#a184ff365a09b7ad654df79a09d0053c5a3d54dff4abfd3d5a1362bb6f47ed2309", null ],
      [ "ValueC", "class_full_inspector_1_1_samples_1_1_binary_formatter_sample_1_1_sample_binary_formatter_dictionaries.html#a184ff365a09b7ad654df79a09d0053c5af85e7eb1c94f5ae33930aa5725a9de6f", null ]
    ] ],
    [ "EnumTransformDict", "class_full_inspector_1_1_samples_1_1_binary_formatter_sample_1_1_sample_binary_formatter_dictionaries.html#accff3698746af278e5c090697cb6e225", null ],
    [ "StrStrDict", "class_full_inspector_1_1_samples_1_1_binary_formatter_sample_1_1_sample_binary_formatter_dictionaries.html#a2b091dd4cb83dd0de7a2c116344bd253", null ]
];