var class_full_inspector_1_1_modules_1_1_static_inspector_1_1_static_inspector_window =
[
    [ "OnGUI", "class_full_inspector_1_1_modules_1_1_static_inspector_1_1_static_inspector_window.html#acc1acf667e3cfa596ddf4a5827f6197c", null ],
    [ "_inspectedType", "class_full_inspector_1_1_modules_1_1_static_inspector_1_1_static_inspector_window.html#ab9453096af072a5e402962970dfce5fa", null ]
];