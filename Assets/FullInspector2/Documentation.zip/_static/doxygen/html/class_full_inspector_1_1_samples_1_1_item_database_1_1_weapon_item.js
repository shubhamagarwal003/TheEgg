var class_full_inspector_1_1_samples_1_1_item_database_1_1_weapon_item =
[
    [ "WeaponType", "class_full_inspector_1_1_samples_1_1_item_database_1_1_weapon_item.html#ab6b711e1f95e4dba27c2e9889c080e33", [
      [ "Sword", "class_full_inspector_1_1_samples_1_1_item_database_1_1_weapon_item.html#ab6b711e1f95e4dba27c2e9889c080e33a6c198603789a4928477eccd5d550b6b2", null ],
      [ "Axe", "class_full_inspector_1_1_samples_1_1_item_database_1_1_weapon_item.html#ab6b711e1f95e4dba27c2e9889c080e33aed4dd6cc118ab2500715cbd23b054573", null ],
      [ "Hammer", "class_full_inspector_1_1_samples_1_1_item_database_1_1_weapon_item.html#ab6b711e1f95e4dba27c2e9889c080e33ae16aadf94681c0f97fa7a25d37e3c8c9", null ]
    ] ],
    [ "AttackStrength", "class_full_inspector_1_1_samples_1_1_item_database_1_1_weapon_item.html#abfec917c7514f530ea5680d2f7224702", null ],
    [ "Type", "class_full_inspector_1_1_samples_1_1_item_database_1_1_weapon_item.html#a68eb84b87e85b7b604ee2477e99582c8", null ]
];