var class_full_inspector_1_1_samples_1_1_games_1_1_arena_1_1_sample_arena_player_controller =
[
    [ "Awake", "class_full_inspector_1_1_samples_1_1_games_1_1_arena_1_1_sample_arena_player_controller.html#a277fb7d5905764065b79aaabe88ff874", null ],
    [ "FixedUpdate", "class_full_inspector_1_1_samples_1_1_games_1_1_arena_1_1_sample_arena_player_controller.html#ae7b2b7daffe833781bce45b7c190f7cf", null ],
    [ "OnDestroy", "class_full_inspector_1_1_samples_1_1_games_1_1_arena_1_1_sample_arena_player_controller.html#a6bac01e4ce82a02d1403879640b0d46c", null ],
    [ "OnTriggerEnter", "class_full_inspector_1_1_samples_1_1_games_1_1_arena_1_1_sample_arena_player_controller.html#ae32b2d0bfcb4fddb6ee6af87210677dd", null ],
    [ "Speed", "class_full_inspector_1_1_samples_1_1_games_1_1_arena_1_1_sample_arena_player_controller.html#a85521f6e67837d10d4579c01ddfa86ab", null ]
];