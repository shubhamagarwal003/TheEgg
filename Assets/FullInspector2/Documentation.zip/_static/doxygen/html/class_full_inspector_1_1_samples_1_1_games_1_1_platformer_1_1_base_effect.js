var class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_base_effect =
[
    [ "Update", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_base_effect.html#a6104544a37563ed9377289e828b16096", null ],
    [ "Duration", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_base_effect.html#ae79a8195f3182a1755ad08102e2a9206", null ],
    [ "IsAlive", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_base_effect.html#a91ee421f7b4be1d578702b133d180b35", null ]
];