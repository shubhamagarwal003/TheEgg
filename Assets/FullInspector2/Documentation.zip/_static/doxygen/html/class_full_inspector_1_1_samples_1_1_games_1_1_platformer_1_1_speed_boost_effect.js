var class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_speed_boost_effect =
[
    [ "SpeedMultiplier", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_speed_boost_effect.html#a23128cba3d3f60dd8c22cfba643d9be6", null ]
];