var class_full_inspector_1_1_samples_1_1_json_net_1_1_custom_type_editor_generic_3_01_t1_00_01_t2_01_4 =
[
    [ "Value1", "class_full_inspector_1_1_samples_1_1_json_net_1_1_custom_type_editor_generic_3_01_t1_00_01_t2_01_4.html#abd264a174b9031dff4df17bf766078d1", null ],
    [ "Value2", "class_full_inspector_1_1_samples_1_1_json_net_1_1_custom_type_editor_generic_3_01_t1_00_01_t2_01_4.html#a737b36952e3ae23561c5348b162b96af", null ]
];