var class_full_inspector_1_1_modules_1_1_common_1_1_bounds_property_editor =
[
    [ "Edit", "class_full_inspector_1_1_modules_1_1_common_1_1_bounds_property_editor.html#a33fdd796c55c881efb763dec6d70c3f3", null ],
    [ "GetElementHeight", "class_full_inspector_1_1_modules_1_1_common_1_1_bounds_property_editor.html#aacd3256e768ea9365afef2b2bd0b4541", null ]
];