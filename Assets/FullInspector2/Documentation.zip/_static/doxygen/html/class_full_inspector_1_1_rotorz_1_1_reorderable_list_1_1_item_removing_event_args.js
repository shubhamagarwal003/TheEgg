var class_full_inspector_1_1_rotorz_1_1_reorderable_list_1_1_item_removing_event_args =
[
    [ "ItemRemovingEventArgs", "class_full_inspector_1_1_rotorz_1_1_reorderable_list_1_1_item_removing_event_args.html#a59245901c3d6e0eb839364d304d5f416", null ],
    [ "adaptor", "class_full_inspector_1_1_rotorz_1_1_reorderable_list_1_1_item_removing_event_args.html#a35c39302032e5c5d2112f00f754f4f51", null ],
    [ "itemIndex", "class_full_inspector_1_1_rotorz_1_1_reorderable_list_1_1_item_removing_event_args.html#a3bd1db137e2cfec3987bd5308a023ffa", null ]
];