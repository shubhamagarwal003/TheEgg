var class_full_inspector_1_1_margin_attribute =
[
    [ "MarginAttribute", "class_full_inspector_1_1_margin_attribute.html#a995f4309d03b9447fcbdec79d0d4348e", null ],
    [ "Margin", "class_full_inspector_1_1_margin_attribute.html#a88f56e21ede4a6132579bd298f723310", null ],
    [ "Order", "class_full_inspector_1_1_margin_attribute.html#ad2fc1a067166c5dd1c507ee506f9c020", null ],
    [ "Order", "class_full_inspector_1_1_margin_attribute.html#a9eff0c1f9da60c018e3206eb91fdb987", null ]
];