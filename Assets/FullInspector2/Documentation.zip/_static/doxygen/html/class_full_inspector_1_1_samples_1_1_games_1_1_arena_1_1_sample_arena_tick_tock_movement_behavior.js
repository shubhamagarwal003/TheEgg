var class_full_inspector_1_1_samples_1_1_games_1_1_arena_1_1_sample_arena_tick_tock_movement_behavior =
[
    [ "FixedUpdate", "class_full_inspector_1_1_samples_1_1_games_1_1_arena_1_1_sample_arena_tick_tock_movement_behavior.html#a1ed1660404a4e2164bb08a8428f618bf", null ],
    [ "Scale", "class_full_inspector_1_1_samples_1_1_games_1_1_arena_1_1_sample_arena_tick_tock_movement_behavior.html#a82ef7926bbc24076aba135a5021fdb51", null ]
];