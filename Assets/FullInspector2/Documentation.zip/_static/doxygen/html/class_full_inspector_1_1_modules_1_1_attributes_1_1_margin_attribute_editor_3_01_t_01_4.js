var class_full_inspector_1_1_modules_1_1_attributes_1_1_margin_attribute_editor_3_01_t_01_4 =
[
    [ "Edit", "class_full_inspector_1_1_modules_1_1_attributes_1_1_margin_attribute_editor_3_01_t_01_4.html#a506ee0c43ea20dfe0986f9a5d350acb2", null ],
    [ "GetElementHeight", "class_full_inspector_1_1_modules_1_1_attributes_1_1_margin_attribute_editor_3_01_t_01_4.html#aa6d23820caaf67307eb2da12a43a5ce6", null ]
];