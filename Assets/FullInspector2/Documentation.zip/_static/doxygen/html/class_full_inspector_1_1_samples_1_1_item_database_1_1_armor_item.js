var class_full_inspector_1_1_samples_1_1_item_database_1_1_armor_item =
[
    [ "Armor", "class_full_inspector_1_1_samples_1_1_item_database_1_1_armor_item.html#a0e3d8118951b3eae0d5a41e68683ec37", null ]
];