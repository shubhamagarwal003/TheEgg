var class_full_inspector_1_1_proto_surrogate_attribute =
[
    [ "ProtoSurrogateAttribute", "class_full_inspector_1_1_proto_surrogate_attribute.html#ae5472bbba49a0708681b725eb42444e2", null ],
    [ "SurrogateFor", "class_full_inspector_1_1_proto_surrogate_attribute.html#ade39e4c6e14e25a32b52b12833c0592b", null ]
];