var class_full_inspector_1_1_samples_1_1_base_skill =
[
    [ "Name", "class_full_inspector_1_1_samples_1_1_base_skill.html#a8bb19adf6137ee97d4412b2111b73573", null ]
];