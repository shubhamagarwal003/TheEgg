var class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_sample_platformer_effect_dispatcher_behavior =
[
    [ "TryDispatch", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_sample_platformer_effect_dispatcher_behavior.html#a6dc1a4b81d521f477d2ac184f9c63393", null ],
    [ "Effects", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_sample_platformer_effect_dispatcher_behavior.html#a273b0d59f89f5ab82f3eebaccf2755a3", null ],
    [ "OnDispatched", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_sample_platformer_effect_dispatcher_behavior.html#aff86501b174b3e54103bc25da58bdcd3", null ]
];