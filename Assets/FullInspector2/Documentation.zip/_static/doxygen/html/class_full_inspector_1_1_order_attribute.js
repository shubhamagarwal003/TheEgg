var class_full_inspector_1_1_order_attribute =
[
    [ "OrderAttribute", "class_full_inspector_1_1_order_attribute.html#adb072ae8ce70560ba68d20ab1d662ea3", null ],
    [ "Order", "class_full_inspector_1_1_order_attribute.html#a465fdf604d032bf1a4a8bc775fb9e5ed", null ]
];