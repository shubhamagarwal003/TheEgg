var class_full_inspector_1_1_samples_1_1_item_database_1_1_health_boost_item =
[
    [ "Cooldown", "class_full_inspector_1_1_samples_1_1_item_database_1_1_health_boost_item.html#a6c9735a1b9237ab5375ec5ddcb408817", null ],
    [ "HealthIncrease", "class_full_inspector_1_1_samples_1_1_item_database_1_1_health_boost_item.html#a9d7be7d80c42bc4ee8756a88e1abfcc0", null ]
];