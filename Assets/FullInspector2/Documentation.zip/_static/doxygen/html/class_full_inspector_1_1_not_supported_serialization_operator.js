var class_full_inspector_1_1_not_supported_serialization_operator =
[
    [ "RetrieveObjectReference", "class_full_inspector_1_1_not_supported_serialization_operator.html#ab634abfa70eccbe3a437e21e34f10382", null ],
    [ "StoreObjectReference", "class_full_inspector_1_1_not_supported_serialization_operator.html#a137e3cdfdae53f7cbf2bc4872db905f8", null ]
];