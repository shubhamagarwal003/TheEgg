var class_full_inspector_1_1_samples_1_1_ice_skill =
[
    [ "Duration", "class_full_inspector_1_1_samples_1_1_ice_skill.html#a772a0062102bb13ced767fe227b5a0ab", null ],
    [ "EnableSlow", "class_full_inspector_1_1_samples_1_1_ice_skill.html#aa25a0d62db52fbd61fdd301f3fe581ed", null ]
];