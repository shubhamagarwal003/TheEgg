var class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_jump_boost_effect =
[
    [ "JumpMultiplier", "class_full_inspector_1_1_samples_1_1_games_1_1_platformer_1_1_jump_boost_effect.html#a8408690e5e246220f36d64c09bcc94d1", null ]
];