var annotated =
[
    [ "FullInspector", "namespace_full_inspector.html", "namespace_full_inspector" ]
];